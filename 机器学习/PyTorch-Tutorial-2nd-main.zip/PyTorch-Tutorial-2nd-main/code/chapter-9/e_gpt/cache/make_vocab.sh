python make_vocab.py \
  --raw_data_path ../data/train.json \
  --vocab_file vocab_user.txt \
  --vocab_size 50000